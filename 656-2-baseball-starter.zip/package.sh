#!/usr/bin/env bash

zip -r 356-2-baseball-starter.zip *
