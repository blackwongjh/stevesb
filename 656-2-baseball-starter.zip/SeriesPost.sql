-- FOREIGN KEY `fk_SeriesPost_Teams`;

ALTER TABLE `SeriesPost` ADD INDEX `idx_SeriesPost_TeamsWin` (`yearID`, `lgIDwinner`, `teamIDwinner`) USING BTREE;
ALTER TABLE `SeriesPost` ADD INDEX `idx_SeriesPost_TeamsLose` (`yearID`, `lgIDloser`, `teamIDloser`) USING BTREE;

DELETE SeriesPost FROM SeriesPost
  INNER JOIN
  (SELECT
     SeriesPost.yearID,
     SeriesPost.lgIDwinner,
     SeriesPost.teamIDwinner
   FROM
     SeriesPost
     LEFT JOIN Teams
       ON SeriesPost.yearID = Teams.yearID AND SeriesPost.teamIDwinner = Teams.teamID AND SeriesPost.lgIDwinner = Teams.lgID
   WHERE Teams.yearID IS NULL OR Teams.lgID IS NULL OR Teams.teamID IS NULL
  ) AS X
    ON SeriesPost.yearID = X.yearID AND SeriesPost.lgIDwinner = X.lgIDwinner AND SeriesPost.teamIDwinner = X.teamIDwinner;
    
DELETE SeriesPost FROM SeriesPost
  INNER JOIN
  (SELECT
     SeriesPost.yearID,
     SeriesPost.lgIDloser,
     SeriesPost.teamIDloser
   FROM
     SeriesPost
     LEFT JOIN Teams
       ON SeriesPost.yearID = Teams.yearID AND SeriesPost.teamIDloser = Teams.teamID AND SeriesPost.lgIDloser = Teams.lgID
   WHERE Teams.yearID IS NULL OR Teams.lgID IS NULL OR Teams.teamID IS NULL
  ) AS X
    ON SeriesPost.yearID = X.yearID AND SeriesPost.lgIDloser = X.lgIDloser AND SeriesPost.teamIDloser = X.teamIDloser; 

ALTER TABLE `SeriesPost` ADD CONSTRAINT `fk_SeriesPost_TeamsWin` FOREIGN KEY (`yearID`, `lgIDwinner`, `teamIDwinner`) REFERENCES `Teams` (`yearID`, `lgID`, `teamID`)
  ON DELETE CASCADE
  ON UPDATE CASCADE;
ALTER TABLE `SeriesPost` ADD CONSTRAINT `fk_SeriesPost_TeamsLose` FOREIGN KEY (`yearID`, `lgIDloser`, `teamIDloser`) REFERENCES `Teams` (`yearID`, `lgID`, `teamID`)
  ON DELETE CASCADE
  ON UPDATE CASCADE;    
    