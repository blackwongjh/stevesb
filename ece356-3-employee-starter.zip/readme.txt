1.sql

Fill in the blanks!

2.sql

Simple update query for the desired results.

3.sql

Run Explain on the update statement in 2

4.sql

Create necessary primary keys

Run Explain on Employee, Project, Assigned, Department (follow order)

Run explain on update query in 2

5.sql

Create necessary foreign keys.

Run Explain on Employee, Project, Assigned, Department. (follow order)

Run explain on update query in 2

6.sql

Create necessary indexes.

Run Explain on Employee, Project, Assigned, Department. (follow order)

Run explain on update query in 2

7.sql

Write the procedure. Do not forget to add "DROP PROCEDURE IF EXISTS <Procedure-Name>;" statements before any procedure that you create.





