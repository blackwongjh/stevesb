DROP PROCEDURE IF EXISTS payRaise;

DELIMITER @@
CREATE PROCEDURE payRaise(IN inEmpID INT,IN inPercentageRaise Double(4, 2), OUT errorCode INT)

top: BEGIN
declare res int default 0;
declare finished int default 0;
declare emp_cur cursor for select empID from Employee where empID = inEmpID;
declare continue handler for NOT FOUND set finished = 1;

IF inPercentageRaise < 0 or inPercentageRaise > 10 THEN
    set errorCode = -1;
    leave top;
END IF;

open emp_cur;
fetch emp_cur into res;

IF finished THEN
    set errorCode = -2;
    leave top;
ELSE
    update Employee set salary = salary * (inPercentageRaise / 100 + 1) where empID = inEmpID;
    set errorCode = 0;
END IF;
close emp_cur;
END@@
DELIMITER ;
call payRaise(3,10,@errorCode);