#!/usr/bin/env bash

zip -r ece356-3-employee-starter.zip *
