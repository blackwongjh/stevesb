DROP PROCEDURE IF EXISTS payRaise;

DELIMITER @@
CREATE PROCEDURE payRaise(IN inEmpID INT,IN inPercentageRaise Double(4, 2), OUT errorCode INT)
BEGIN	
	if (select empID from Employee where empID = inEmpID) is NULL then
		set errorCode = -2;
	end if;
    
	if inPercentageRaise > 10 or inPercentageRaise < 0 then
		set errorCode = -1;
	end if;
    
    if ((select salary from Employee where empID = inEmpID) * (1+inPercentageRaise/100)) >= 100000 then
    	set errorCode = -3;
    end if;

    if errorCode is NULL then
    update Employee set salary = salary *(1+inPercentageRaise/100) where empID = inEmpID;
           set errorCode = 0;
	end if;

END@@
DELIMITER ; 

update Employee 
	set salary = case when (select count(*) from (select salary from Employee where salary*1.03 > 100000)as a) > 0 then salary else salary*1.03 END
	where empID in 
	(select empID from (Department natural join (select b.* from Employee as b)as a) where location = 'kitchener');