CREATE INDEX Location
ON Department (location);

explain Employee;
explain Project;
explain Assigned;
explain Department;

explain update Employee set salary = salary * 1.05
		where empID in 
		(select empID from 
			(Department natural join (select b.* from Employee as b)as a) where location = 'Waterloo');
