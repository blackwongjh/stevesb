DROP VIEW IF EXISTS Employee_View;
CREATE VIEW Employee_View as select empID,firstName,midName,lastName,job,deptID,salary from Employee natural join Employee_Department;