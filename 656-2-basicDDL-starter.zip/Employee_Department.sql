DROP TABLE IF EXISTS Employee_Department;
CREATE TABLE Employee_Department (
	empID INT,
	deptID INT,
	primary key(empID,deptID),
    FOREIGN KEY (deptID) REFERENCES Department(deptID),
    FOREIGN KEY (empID) REFERENCES Employee(empID)
) CHARACTER SET 'utf8';
