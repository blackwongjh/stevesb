DROP TABLE IF EXISTS Project;
CREATE TABLE Project (
	projID INT,
	title VARCHAR(100),
    budget INT,
    funds INT,
    primary key(projID)
) CHARACTER SET 'utf8';