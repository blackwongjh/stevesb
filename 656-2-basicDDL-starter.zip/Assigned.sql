DROP TABLE IF EXISTS Assigned;
CREATE TABLE Assigned(

	empID INT,
    projID INT,
    role VARCHAR(100),
    primary key(empID,projID,role),
    FOREIGN KEY (empID) REFERENCES Employee(empID),
    FOREIGN KEY (projID) REFERENCES Project(projID)
)CHARACTER SET 'utf8';