DROP TABLE IF EXISTS Location;
CREATE TABLE Location (
	deptID INT,
    streetNum VARCHAR(100),
    streetName VARCHAR(100),
	postCode VARCHAR(100),
    primary key(deptID,
    streetNum,
    streetName,
	postCode),
    FOREIGN KEY (deptID) REFERENCES Department(deptID),
    FOREIGN KEY (postCode) REFERENCES City(postCode)
) CHARACTER SET 'utf8';