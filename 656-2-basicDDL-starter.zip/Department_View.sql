DROP VIEW IF EXISTS Department_View;
CREATE VIEW Department_View as select deptID,deptName,streetNum,streetName,cityName,postCode from City natural join Location natural join Department;