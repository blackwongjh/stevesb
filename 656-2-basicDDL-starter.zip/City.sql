DROP TABLE IF EXISTS City;
CREATE TABLE City (
	postCode VARCHAR(100),
    cityName VARCHAR(100),
    primary key(postCode)
) CHARACTER SET 'utf8';