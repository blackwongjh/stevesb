DROP TABLE IF EXISTS Department;
CREATE TABLE Department (
	deptID INT,
    deptName VARCHAR(100),
    primary key (deptID)
) CHARACTER SET 'utf8';