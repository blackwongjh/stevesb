#!/usr/bin/env bash

zip -r 356-2-basicDDL-starter.zip *
