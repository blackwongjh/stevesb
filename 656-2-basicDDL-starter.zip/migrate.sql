INSERT INTO City(postCode,cityName)
VALUES('E2H9Y0','Toronto'),
      ('E2I3Y0','Waterloo'),
      ('P9I3Y0','Markham'),
      ('T9Y5N6','Kitchener');

INSERT INTO Department(deptID,deptName)
VALUES(3, 'marketing'),
      (7, 'research' ),
      (12, 'software'),
      (13, 'computing');

INSERT INTO Location(deptID, streetNum, streetName, postCode)
VALUES(3, '123', 'Second', 'E2H9Y0'   ),
      (7, '234','Pine','E2I3Y0'   ),
      (7,  '456','Chruch','P9I3Y0'   ),
      (12, '456','Chruch' ,'P9I3Y0'   ),
      (13, '998','Maple','T9Y5N6'   );

INSERT INTO Employee(empID,firstName,midName,lastName,job,salary)
VALUES(23, 'Smith',NULL,'Murphy', 'programmer', 35000),
(45, 'Kellyily',NULL, 'Smith', 'engineer',45000),
(56, 'Herr',NULL, 'Lam', 'janitor', 26000),
(89, 'Williams', 'M', 'Brown', 'analyst',36000),
(77, 'Hergot',NULL, 'Roy', 'secretary',28000),
(66, 'Hess',NULL, 'Tremblay', 'technician', 32000),
(92, 'Mays', 'K', 'Lee', 'engineer', 45000),
(68, 'Morris',NULL, 'Gagnon', 'secretary',  23000),
(69, 'Maria', 'Tom', 'Wilson', 'engineer', 32000);


INSERT INTO Employee_Department(empID,deptID)
VALUES( 23,12  ),
      (  45,7 ),
      (  56,7 ),
      (89,12   ),
      ( 77,7  ),
      (  66,7 ),
      ( 92,7  ),
      (  68,3 ),
      (  69,3 );

INSERT INTO Project(projID, title, budget, funds)
VALUES(345, 'compiler', 500000, 250000),
(123, 'display', 650000, 370000);

INSERT INTO Assigned(empID, projID, role) 
VALUES(23, 345, 'programmer'),
(66, 123, 'programmer'),
(66, 123, 'manager'),
(66, 345, 'manager'),
(77, 123, 'secretary'),
(45, 123, 'manager'),
(89, 345, 'manager'),
(92, 123, 'engineer');



