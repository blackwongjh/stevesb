DROP TABLE IF EXISTS Employee;
CREATE TABLE Employee (
	empID INT,
	firstName VARCHAR(100), 
    midName VARCHAR(100),
    lastName VARCHAR(100),
    job VARCHAR(100),
    salary INT,
	primary key(empID),
    check (salary >= 20000 and salary <= 150000 )
) CHARACTER SET 'utf8';
