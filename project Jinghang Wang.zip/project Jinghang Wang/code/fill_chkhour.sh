#!/bin/bash
for i in `seq 0 23`
do
mysql -uyelp -pyelp yelp -e "update chkhour c, (select business_id, sum(\`number\`) ccount from checkin where hour = 0 group by business_id) n set c.h0 = n.ccount where c.business_id=n.business_id"
done
