create table main(
    business_id char(22) primary key,
    review_count int,
    stars decimal(2, 1),
    checkin_count int);

create table simpleReview (
    id int primary key auto_increment,
    business_id char(22),
    stars decimal(2, 1),
    char_count int,
    useful int,
    funny int,
    cool int,
    foreign key (business_id) references main(business_id));

/* Select data from original table review, insert into simpeReview */
insert into simpleReview (business_id, stars, char_count, useful, funny, cool)
    select business_id, stars, length(text), useful, funny, cool from review;

/* Add index to column char_count */
alter table simpleReview add index char_count using btree;

/* Clean data */
delete from simpleReview where char_count < 50 or char_count > 4000;

update main m, (select business_id, count(*) review_count from simpleReview group by business_id) n set m.review_count=n.review_count where m.business_id=n.business_id;

update main m, (select business_id, avg(stars) avg_stars from simpleReview group by business_id) n set m.stars=n.avg_stars where m.business_id=n.business_id;

create table chkhour (
    business_id char(22) primary key,
    stars decimal(2, 1),
    h0 int default 0,
    h1 int default 0,
    h2 int default 0,
    h3 int default 0,
    h4 int default 0,
    h5 int default 0,
    h6 int default 0,
    h7 int default 0,
    h8 int default 0,
    h9 int default 0,
    h10 int default 0,
    h11 int default 0,
    h12 int default 0,
    h13 int default 0,
    h14 int default 0,
    h15 int default 0,
    h16 int default 0,
    h17 int default 0,
    h18 int default 0,
    h19 int default 0,
    h20 int default 0,
    h21 int default 0,
    h22 int default 0,
    h23 int default 0,
    foreign key (business_id) references main(business_id)
);
insert into chkhour(business_id, stars) select business_id, stars from main;

/* Add index to column hour */
alter table checkin add index (hour) using btree;

/* Update chkhour's 24 columns, this is an example, all are done in fill_chkhour.sh */
update chkhour c, (select business_id, sum(`number`) ccount from checkin where hour = 0 group by business_id) n set c.h0 = n.ccount where c.business_id=n.business_id;
