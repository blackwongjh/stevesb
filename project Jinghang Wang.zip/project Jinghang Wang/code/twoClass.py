#!/usr/bin/python
import MySQLdb
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB, BernoulliNB
from sklearn import svm
from sklearn.metrics import classification_report, accuracy_score
import numpy as np

MEDIAN = 3.7

def main():
    conn = MySQLdb.connect('127.0.0.1', 'yelp', 'yelp', 'yelp')
    rawStars = pd.read_sql('select if(stars < %s, 0, 1) level, h0, h1, h2,\
            h3, h4, h5, h6, h7, h8, h9, h10, h11, h12, h13, h14, h15, h16,\
            h17, h18, h19, h20, h21, h22, h23 from chkhour' % MEDIAN, con=conn)
    X_train, X_test, y_train, y_test = train_test_split(
            rawStars.filter(items=[
                'h0', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'h7', 'h8', 'h9', 'h10'
                'h11', 'h12', 'h13', 'h14', 'h15', 'h16', 'h17', 'h18', 'h19',
                'h20', 'h21', 'h22', 'h23']),
            rawStars.filter(items=['level']),
            test_size=0.2, random_state=37)

    yy = np.asarray(y_train['level'], dtype="int64")
    xx = np.asarray(X_train, dtype="int64")

    algorithms = {
            'SVM': svm.SVC,
            'Gaussian': GaussianNB,
            'Bernoulli': BernoulliNB}

    for _name, _algorithm in algorithms.items():
        clf = _algorithm()
        clf.fit(xx, yy)
        predicted = clf.predict(X_test)
        print "Result of %s:" % _name
        print classification_report(
                np.asarray(y_test['level'], dtype="int64"), predicted)
        print "Accuracy %s" % accuracy_score(
                np.asarray(y_test['level'], dtype="int64"), predicted)
        print

if __name__ == "__main__":
    main()
